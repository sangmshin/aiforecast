// Include the cluster module
var cluster = require('cluster');

// Code to run if we're in the master process
if (cluster.isMaster) {

  // Count the machine's CPUs
  var cpuCount = require('os').cpus().length;

  // Create a worker for each CPU
  for (var i = 0; i < cpuCount; i += 1) {
    cluster.fork();
  }

  // Listen for terminating workers
  cluster.on('exit', function (worker) {

    // Replace the terminated workers
    console.log('Worker ' + worker.id + ' died :(');
    cluster.fork();

  });

  // Code to run if we're in a worker process
} else {

var AWS = require('aws-sdk');

const express = require('express')
const app = express()
const reload = require('reload')
const bodyParser = require('body-parser')
const path = require('path')
const fs = require('fs')

const PORT = process.env.PORT || 3000;

AWS.config.region = process.env.REGION


app.use(express.urlencoded({
  extended: true
}));
app.use(bodyParser.urlencoded({
  extended: true
}));
app.use(express.json());
app.use(bodyParser.json());


// TEMPLATE ENGINE
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'hbs');


// STATIC FOLDER
app.use(express.static(path.join(__dirname, 'public')))


// ROUTES
app.use(require('./routes/index'))


// SERVER
app.listen(PORT, () => {
  console.log(`We are live and magic happens on port ${PORT}`);
})


// LIVERELOAD
reload(app, {
  verbose: true
})


// module.exports.server = sls(app)
